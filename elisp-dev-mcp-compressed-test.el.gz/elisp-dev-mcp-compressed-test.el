;;; elisp-dev-mcp-compressed-test.el --- Test fixtures for compressed file handling -*- lexical-binding: t -*-

;; Copyright (C) 2026 Laurynas Biveinis

;; This file is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation; either version 3, or (at your option)
;; any later version.

;; This file is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with this program.  If not, see <https://www.gnu.org/licenses/>.

;; Author: Laurynas Biveinis
;; Keywords: tools, development
;; URL: https://github.com/laurynas-biveinis/elisp-dev-mcp

;;; Commentary:

;; Test fixture for testing compressed .el.gz file handling.
;; This file exists ONLY as .el.gz (no .el) to verify that
;; elisp-dev-mcp tools work correctly with compressed source files.

;;; Code:

;; Header comment for compressed file test function
;; This should be included when extracting the definition
(defun elisp-dev-mcp-compressed-test--sample-function (x y)
  "A test function for compressed file handling.
X and Y are numbers to be multiplied."
  (* x y))

(provide 'elisp-dev-mcp-compressed-test)

;; Local Variables:
;; package-lint-main-file: "elisp-dev-mcp.el"
;; End:

;;; elisp-dev-mcp-compressed-test.el ends here
